import {
  closestCenter,
  DndContext,
  type DragEndEvent,
  type DragStartEvent,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
} from '@dnd-kit/core';
import {
  SortableContext,
  sortableKeyboardCoordinates,
  useSortable,
  verticalListSortingStrategy,
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import {
  ChevronDown,
  ChevronUp,
  Copy,
  Grid2x2,
  ListOrdered,
  type LucideIcon,
  Sparkles,
  Trash2,
} from 'lucide-react';
import { Fragment, useCallback, useEffect, useLayoutEffect, useRef, useState } from 'react';
import { useOptionalInspector } from '@/components/inspector/inspector-provider';
import { Button } from '@/components/ui/button';
import {
  ContextMenu,
  ContextMenuContent,
  ContextMenuItem,
  ContextMenuSeparator,
  ContextMenuTrigger,
} from '@/components/ui/context-menu';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { format, plural, useLocale } from '@/lib/use-locale';
import { cn, pad2 } from '@/lib/utils';
import type { DesignSystem } from '../lib/design';
import { SlidePageProvider } from '../lib/page-context';
import type { Page } from '../lib/sdk';
import { CANVAS_HEIGHT, CANVAS_WIDTH } from '../lib/sdk';
import type { SlideTransition } from '../lib/transition';
import { prefersReducedMotion } from '../lib/use-prefers-reduced-motion';
import { SlideCanvas } from './slide-canvas';
import {
  getCenteredThumbnailScrollTop,
  getThumbnailOffscreenDirection,
  type ThumbnailOffscreenDirection,
} from './thumbnail-rail-scroll';

type Orientation = 'vertical' | 'horizontal';

export type ThumbnailActions = {
  onDuplicate: (index: number) => void;
  onDelete: (index: number) => void;
};

type Props = {
  pages: Page[];
  design?: DesignSystem;
  current: number;
  onSelect: (index: number) => void;
  onReorder?: (from: number, to: number) => void;
  actions?: ThumbnailActions;
  orientation?: Orientation;
  /** Vertical-only: total rail width in px. Thumbnails scale to fit. */
  width?: number;
  /** Deck-level transition default; used to flag pages that inherit a transition. */
  moduleTransition?: SlideTransition;
  /** When provided, the vertical rail header renders a button that opens the overview grid. */
  onOverview?: () => void;
};

// Per-page pending comment counts, shown on the rail only while the
// comment tool is active.
function usePageCommentCounts(): Map<number, number> | null {
  const inspector = useOptionalInspector();
  if (!inspector?.commentMode) return null;
  const counts = new Map<number, number>();
  for (const comment of inspector.comments) {
    if (comment.page === undefined) continue;
    counts.set(comment.page, (counts.get(comment.page) ?? 0) + 1);
  }
  return counts;
}

function CommentCountBadge({ count, className }: { count: number; className?: string }) {
  const t = useLocale();
  return (
    <span
      role="img"
      aria-label={format(plural(count, t.inspector.commentsCount), { count })}
      data-page-comments={count}
      className={cn(
        'flex h-4 min-w-4 items-center justify-center rounded-full bg-brand px-1 font-mono text-[9.5px] font-semibold leading-none text-brand-foreground tabular-nums',
        className,
      )}
    >
      {count}
    </span>
  );
}

const DEFAULT_VERTICAL_THUMB_WIDTH = 184;
const VERTICAL_RAIL_CHROME = 80;
const MIN_VERTICAL_THUMB_WIDTH = 120;
const HORIZONTAL_THUMB_HEIGHT = 64;
const HORIZONTAL_THUMB_GAP = 8;
const HORIZONTAL_RAIL_PADDING_X = 12;
const HORIZONTAL_RAIL_PADDING_Y = 10;
const HORIZONTAL_LABEL_HEIGHT = 12;
const HORIZONTAL_LABEL_GAP = 6;
const VERTICAL_THUMB_PADDING_Y = 12;
const VERTICAL_THUMB_GAP = 8;
const VIRTUAL_OVERSCAN = 4;

export function ThumbnailRail({
  pages,
  design,
  current,
  onSelect,
  onReorder,
  actions,
  orientation = 'vertical',
  width,
  moduleTransition,
  onOverview,
}: Props) {
  const activeRef = useRef<HTMLButtonElement | null>(null);
  const virtualListRef = useRef<HTMLDivElement | null>(null);
  const verticalViewportRef = useRef<HTMLElement | null>(null);
  const focusCurrentAfterScrollRef = useRef(false);
  const focusAfterArrowRef = useRef(false);
  const [currentPosition, setCurrentPosition] = useState<ThumbnailOffscreenDirection>(null);
  const t = useLocale();

  const setVerticalScrollElements = useCallback(
    (viewport: HTMLElement | null, root: HTMLDivElement | null) => {
      verticalViewportRef.current = viewport;
      virtualListRef.current = root;
    },
    [],
  );

  const cancelPendingFocus = useCallback(() => {
    focusCurrentAfterScrollRef.current = false;
  }, []);

  const thumbWidth =
    width != null
      ? Math.max(MIN_VERTICAL_THUMB_WIDTH, width - VERTICAL_RAIL_CHROME)
      : DEFAULT_VERTICAL_THUMB_WIDTH;
  const scale = thumbWidth / CANVAS_WIDTH;
  const height = CANVAS_HEIGHT * scale;
  const rowHeight = height + VERTICAL_THUMB_PADDING_Y + VERTICAL_THUMB_GAP;

  const scrollToCurrent = useCallback(
    (focusCurrent: boolean) => {
      const viewport = verticalViewportRef.current;
      const root = virtualListRef.current;
      if (!viewport || !root || pages.length <= 0) return;

      focusCurrentAfterScrollRef.current = focusCurrent;
      const clampedCurrent = Math.min(Math.max(current, 0), pages.length - 1);
      const topInset = root.offsetTop;
      const itemTop = topInset + clampedCurrent * rowHeight;
      viewport.scrollTo({
        top: getCenteredThumbnailScrollTop({
          itemTop,
          itemHeight: rowHeight,
          viewportHeight: viewport.clientHeight,
          topInset,
        }),
        behavior: scrollBehavior(),
      });
    },
    [current, pages.length, rowHeight],
  );

  useEffect(() => {
    if (currentPosition !== null || !focusCurrentAfterScrollRef.current) return;
    let frame = 0;
    let attempts = 0;
    const focusCurrent = () => {
      if (!focusCurrentAfterScrollRef.current) return;
      const active = activeRef.current;
      if (active) {
        active.focus({ preventScroll: true });
        focusCurrentAfterScrollRef.current = false;
        return;
      }
      attempts += 1;
      if (attempts < 4) {
        frame = requestAnimationFrame(focusCurrent);
      } else {
        focusCurrentAfterScrollRef.current = false;
      }
    };
    frame = requestAnimationFrame(focusCurrent);
    return () => cancelAnimationFrame(frame);
  }, [currentPosition]);

  useLayoutEffect(() => {
    if (!focusAfterArrowRef.current || !activeRef.current) return;
    activeRef.current.focus({ preventScroll: true });
    focusAfterArrowRef.current = false;
  });

  const onThumbnailArrowKeyDown = useCallback(
    (event: React.KeyboardEvent<HTMLButtonElement>, index: number) => {
      if (event.altKey || event.ctrlKey || event.metaKey || event.nativeEvent.isComposing) return;
      const direction =
        event.key === 'ArrowRight' || event.key === 'ArrowDown'
          ? 1
          : event.key === 'ArrowLeft' || event.key === 'ArrowUp'
            ? -1
            : 0;
      if (!direction) return;
      event.preventDefault();
      event.stopPropagation();
      const next = Math.min(Math.max(index + direction, 0), pages.length - 1);
      if (next === index) return;
      focusAfterArrowRef.current = true;
      onSelect(next);
    },
    [onSelect, pages.length],
  );

  const renderThumb = useCallback(
    (PageComp: Page, i: number) => {
      const active = i === current;
      const inner = (
        <ThumbContents
          index={i}
          total={pages.length}
          active={active}
          page={PageComp}
          design={design}
          scale={scale}
          thumbWidth={thumbWidth}
          height={height}
          moduleTransition={moduleTransition}
        />
      );

      const node = onReorder ? (
        <SortableThumb
          index={i}
          active={active}
          activeRef={active ? activeRef : undefined}
          onSelect={() => onSelect(i)}
          onArrowKeyDown={(event) => onThumbnailArrowKeyDown(event, i)}
          ariaLabel={format(t.thumbnailRail.goToPageAria, { n: i + 1 })}
        >
          {inner}
        </SortableThumb>
      ) : (
        <button
          type="button"
          ref={active ? activeRef : undefined}
          onClick={() => onSelect(i)}
          onKeyDown={(event) => onThumbnailArrowKeyDown(event, i)}
          aria-label={format(t.thumbnailRail.goToPageAria, { n: i + 1 })}
          aria-current={active ? 'page' : undefined}
          className={thumbButtonClass(active)}
        >
          {inner}
        </button>
      );

      if (!actions) {
        return <Fragment key={i}>{node}</Fragment>;
      }
      return (
        <ThumbContextMenu
          key={i}
          index={i}
          actions={actions}
          pageCount={pages.length}
          ariaLabel={format(t.thumbnailRail.pageActionsAria, { n: i + 1 })}
        >
          {node}
        </ThumbContextMenu>
      );
    },
    [
      actions,
      current,
      design,
      height,
      moduleTransition,
      onReorder,
      onSelect,
      onThumbnailArrowKeyDown,
      pages.length,
      scale,
      thumbWidth,
      t.thumbnailRail.goToPageAria,
      t.thumbnailRail.pageActionsAria,
    ],
  );

  if (orientation === 'horizontal') {
    const scale = HORIZONTAL_THUMB_HEIGHT / CANVAS_HEIGHT;
    const horizontalWidth = CANVAS_WIDTH * scale;
    return (
      <div className="bg-sidebar">
        <div className="overflow-x-auto overflow-y-hidden">
          <HorizontalVirtualThumbList
            pages={pages}
            design={design}
            current={current}
            actions={actions}
            activeRef={activeRef}
            onSelect={onSelect}
            onArrowKeyDown={onThumbnailArrowKeyDown}
            scale={scale}
            thumbWidth={horizontalWidth}
          />
        </div>
      </div>
    );
  }

  const list = (
    <aside className="flex flex-col gap-2 px-3 pb-3">
      <div className="-mx-3 sticky top-0 z-10 bg-sidebar px-4 pt-3 pb-1">
        <div className="flex items-center justify-between gap-2">
          <span className="eyebrow">{t.thumbnailRail.pages}</span>
          <div className="flex items-center gap-1.5">
            <span className="folio">{pad2(pages.length)}</span>
            {onOverview && (
              <Tooltip>
                <TooltipTrigger
                  render={
                    <button
                      type="button"
                      onClick={onOverview}
                      aria-label={t.thumbnailRail.overviewAria}
                      className={cn(
                        'flex size-5 items-center justify-center rounded-[3px] text-muted-foreground/70 outline-none',
                        'motion-safe:transition-colors hover:bg-muted hover:text-foreground',
                        'focus-visible:ring-1 focus-visible:ring-brand',
                      )}
                    >
                      <Grid2x2 className="size-3.5" strokeWidth={1.75} />
                    </button>
                  }
                />
                <TooltipContent side="bottom" sideOffset={6}>
                  {t.thumbnailRail.overviewAria}
                </TooltipContent>
              </Tooltip>
            )}
          </div>
        </div>
      </div>
      <VirtualThumbList
        pages={pages}
        current={current}
        rowHeight={rowHeight}
        activeRef={activeRef}
        onScrollElementsChange={setVerticalScrollElements}
        onScrollInteraction={cancelPendingFocus}
        onCurrentPositionChange={setCurrentPosition}
        renderThumb={renderThumb}
      />
    </aside>
  );

  const scrollAreaContents = onReorder ? (
    <SortableRail pages={pages} onReorder={onReorder} onSelect={onSelect}>
      {list}
    </SortableRail>
  ) : (
    list
  );

  return (
    <TooltipProvider delay={200}>
      <div className="relative h-full">
        <ScrollArea className="h-full bg-sidebar [&_[data-slot=scroll-area-scrollbar]]:z-20">
          {scrollAreaContents}
        </ScrollArea>
        {currentPosition && (
          <CurrentThumbnailButton
            direction={currentPosition}
            label={format(
              currentPosition === 'above'
                ? t.thumbnailRail.scrollUpToCurrentPage
                : t.thumbnailRail.scrollDownToCurrentPage,
              { n: current + 1 },
            )}
            onActivate={scrollToCurrent}
          />
        )}
      </div>
    </TooltipProvider>
  );
}

function CurrentThumbnailButton({
  direction,
  label,
  onActivate,
}: {
  direction: Exclude<ThumbnailOffscreenDirection, null>;
  label: string;
  onActivate: (focusCurrent: boolean) => void;
}) {
  const Icon = direction === 'above' ? ChevronUp : ChevronDown;
  return (
    <Tooltip>
      <TooltipTrigger
        render={
          <Button
            type="button"
            variant="outline"
            size="icon-sm"
            aria-label={label}
            onClick={(event) => onActivate(event.detail === 0)}
            onKeyDown={(event) => {
              if (event.key === ' ') {
                event.preventDefault();
                event.stopPropagation();
                return;
              }
              if (event.key !== 'Enter') return;
              event.preventDefault();
              event.stopPropagation();
              onActivate(true);
            }}
            onKeyUp={(event) => {
              if (event.key !== ' ') return;
              event.preventDefault();
              event.stopPropagation();
              onActivate(true);
            }}
            className={cn(
              'pointer-events-auto absolute left-1/2 z-30 -translate-x-1/2 bg-card/95 shadow-floating backdrop-blur-sm',
              'motion-safe:animate-in motion-safe:fade-in-0 motion-safe:zoom-in-95 motion-safe:duration-150',
              direction === 'above' ? 'top-10' : 'bottom-3',
            )}
          >
            <Icon className="size-3.5" strokeWidth={1.75} aria-hidden />
          </Button>
        }
      />
      <TooltipContent side={direction === 'above' ? 'bottom' : 'top'} sideOffset={6}>
        {label}
      </TooltipContent>
    </Tooltip>
  );
}

function thumbButtonClass(active: boolean): string {
  return cn(
    'group/thumb flex w-full items-start gap-2.5 rounded-[6px] p-1.5 text-left outline-none motion-safe:transition-[background-color,scale] motion-safe:duration-100',
    'hover:bg-muted/60 active:scale-[0.985]',
    'focus-visible:ring-1 focus-visible:ring-brand focus-visible:ring-offset-1 focus-visible:ring-offset-sidebar',
    active && 'bg-muted',
  );
}

function HorizontalVirtualThumbList({
  pages,
  design,
  current,
  actions,
  activeRef,
  onSelect,
  onArrowKeyDown,
  scale,
  thumbWidth,
}: {
  pages: Page[];
  design?: DesignSystem;
  current: number;
  actions?: ThumbnailActions;
  activeRef: React.MutableRefObject<HTMLButtonElement | null>;
  onSelect: (index: number) => void;
  onArrowKeyDown: (event: React.KeyboardEvent<HTMLButtonElement>, index: number) => void;
  scale: number;
  thumbWidth: number;
}) {
  const rootRef = useRef<HTMLDivElement | null>(null);
  const viewportRef = useRef<HTMLElement | null>(null);
  const t = useLocale();
  const itemWidth = thumbWidth + HORIZONTAL_THUMB_GAP;
  const listHeight =
    HORIZONTAL_RAIL_PADDING_Y * 2 +
    HORIZONTAL_LABEL_HEIGHT +
    HORIZONTAL_LABEL_GAP +
    HORIZONTAL_THUMB_HEIGHT;
  const [range, setRange] = useState(() => getInitialVisibleRange(current, pages.length));

  const updateRange = useCallback(() => {
    const viewport = viewportRef.current;
    if (!viewport) return;
    const scrollLeft = Math.max(0, viewport.scrollLeft - HORIZONTAL_RAIL_PADDING_X);
    setRange(getVisibleRange(scrollLeft, pages.length, viewport.clientWidth, itemWidth));
  }, [itemWidth, pages.length]);

  useLayoutEffect(() => {
    const root = rootRef.current;
    const viewport = root?.parentElement;
    if (!viewport) return;
    viewportRef.current = viewport;

    let frame = 0;
    const scheduleUpdate = () => {
      cancelAnimationFrame(frame);
      frame = requestAnimationFrame(updateRange);
    };
    const resizeObserver = new ResizeObserver(scheduleUpdate);

    viewport.addEventListener('scroll', scheduleUpdate, { passive: true });
    resizeObserver.observe(viewport);
    scheduleUpdate();

    return () => {
      cancelAnimationFrame(frame);
      viewport.removeEventListener('scroll', scheduleUpdate);
      resizeObserver.disconnect();
      if (viewportRef.current === viewport) viewportRef.current = null;
    };
  }, [updateRange]);

  useLayoutEffect(() => {
    if (pages.length <= 0) return;
    const viewport = viewportRef.current ?? rootRef.current?.parentElement;
    if (!viewport) return;
    viewportRef.current = viewport;

    const clampedCurrent = Math.min(Math.max(current, 0), pages.length - 1);
    const left = HORIZONTAL_RAIL_PADDING_X + clampedCurrent * itemWidth;
    const right = left + thumbWidth;
    const viewportLeft = viewport.scrollLeft;
    const viewportRight = viewportLeft + viewport.clientWidth;

    if (left < viewportLeft) {
      viewport.scrollLeft = left;
    } else if (right > viewportRight) {
      viewport.scrollLeft = right - viewport.clientWidth;
    }

    const scrollLeft = Math.max(0, viewport.scrollLeft - HORIZONTAL_RAIL_PADDING_X);
    setRange(getVisibleRange(scrollLeft, pages.length, viewport.clientWidth, itemWidth));
  }, [current, itemWidth, pages.length, thumbWidth]);

  const visibleRange = clampVisibleRange(range, current, pages.length);
  const commentCounts = usePageCommentCounts();
  const visible = [];
  for (let i = visibleRange.start; i < visibleRange.end; i++) {
    const PageComp = pages[i];
    const active = i === current;
    const commentCount = commentCounts?.get(i) ?? 0;
    const button = (
      <button
        type="button"
        ref={active ? activeRef : undefined}
        onClick={() => onSelect(i)}
        onKeyDown={(event) => onArrowKeyDown(event, i)}
        aria-label={format(t.thumbnailRail.goToPageAria, { n: i + 1 })}
        aria-current={active ? 'page' : undefined}
        className={cn(
          'group/thumb relative flex shrink-0 flex-col items-center gap-1.5 rounded-[6px] outline-none motion-safe:transition-[scale] motion-safe:duration-100 active:scale-[0.985]',
          'focus-visible:ring-1 focus-visible:ring-brand focus-visible:ring-offset-1 focus-visible:ring-offset-sidebar',
        )}
      >
        <span
          className={cn(
            'font-mono text-[9.5px] font-medium tracking-[0.06em] tabular-nums uppercase',
            active ? 'text-brand' : 'text-muted-foreground/70',
          )}
        >
          {pad2(i + 1)}
        </span>
        <div
          className={cn(
            'relative shrink-0 overflow-hidden rounded-[4px] border bg-card motion-safe:transition-[border-color,box-shadow]',
            active
              ? 'border-brand shadow-[0_0_0_1px_var(--brand)]'
              : 'border-hairline group-hover/thumb:border-foreground/25',
          )}
          style={{ width: thumbWidth, height: HORIZONTAL_THUMB_HEIGHT }}
        >
          <SlideCanvas scale={scale} center={false} flat freezeMotion design={design}>
            <SlidePageProvider index={i} total={pages.length}>
              <PageComp />
            </SlidePageProvider>
          </SlideCanvas>
        </div>
        {commentCount > 0 && (
          <CommentCountBadge count={commentCount} className="absolute -top-0.5 -right-1" />
        )}
      </button>
    );

    visible.push(
      <div
        key={i}
        className="absolute top-2.5"
        style={{ left: HORIZONTAL_RAIL_PADDING_X + i * itemWidth, width: thumbWidth }}
      >
        {actions ? (
          <ThumbContextMenu
            index={i}
            actions={actions}
            pageCount={pages.length}
            ariaLabel={format(t.thumbnailRail.pageActionsAria, { n: i + 1 })}
          >
            {button}
          </ThumbContextMenu>
        ) : (
          button
        )}
      </div>,
    );
  }

  return (
    <div
      ref={rootRef}
      className="relative"
      style={{
        width: HORIZONTAL_RAIL_PADDING_X * 2 + pages.length * itemWidth - HORIZONTAL_THUMB_GAP,
        height: listHeight,
      }}
    >
      {visible}
    </div>
  );
}

function VirtualThumbList({
  pages,
  current,
  rowHeight,
  activeRef,
  onScrollElementsChange,
  onScrollInteraction,
  onCurrentPositionChange,
  renderThumb,
}: {
  pages: Page[];
  current: number;
  rowHeight: number;
  activeRef: React.MutableRefObject<HTMLButtonElement | null>;
  onScrollElementsChange: (viewport: HTMLElement | null, root: HTMLDivElement | null) => void;
  onScrollInteraction: () => void;
  onCurrentPositionChange: (position: ThumbnailOffscreenDirection) => void;
  renderThumb: (page: Page, index: number) => React.ReactNode;
}) {
  const rootRef = useRef<HTMLDivElement | null>(null);
  const viewportRef = useRef<HTMLElement | null>(null);
  const [range, setRange] = useState(() => getInitialVisibleRange(current, pages.length));

  const updateRange = useCallback(() => {
    const viewport = viewportRef.current;
    const root = rootRef.current;
    if (!viewport || !root) return;
    const scrollTop = Math.max(0, viewport.scrollTop - root.offsetTop);
    setRange(getVisibleRange(scrollTop, pages.length, viewport.clientHeight, rowHeight));

    if (pages.length <= 0) {
      onCurrentPositionChange(null);
      return;
    }

    const clampedCurrent = Math.min(Math.max(current, 0), pages.length - 1);
    const itemTop = root.offsetTop + clampedCurrent * rowHeight;
    onCurrentPositionChange(
      getThumbnailOffscreenDirection({
        itemTop,
        itemBottom: itemTop + rowHeight,
        visibleTop: viewport.scrollTop + root.offsetTop,
        visibleBottom: viewport.scrollTop + viewport.clientHeight,
      }),
    );
  }, [current, onCurrentPositionChange, pages.length, rowHeight]);

  useEffect(() => {
    const root = rootRef.current;
    if (!root) return;
    const viewport = root.closest('[data-slot="scroll-area-viewport"]') as HTMLElement | null;
    if (!viewport) return;
    const scrollArea = viewport.parentElement;
    viewportRef.current = viewport;
    onScrollElementsChange(viewport, root);

    let frame = 0;
    const scheduleUpdate = () => {
      cancelAnimationFrame(frame);
      frame = requestAnimationFrame(updateRange);
    };
    const resizeObserver = new ResizeObserver(scheduleUpdate);

    viewport.addEventListener('scroll', scheduleUpdate, { passive: true });
    scrollArea?.addEventListener('wheel', onScrollInteraction, { passive: true });
    scrollArea?.addEventListener('touchstart', onScrollInteraction, { passive: true });
    scrollArea?.addEventListener('pointerdown', onScrollInteraction, { passive: true });
    resizeObserver.observe(viewport);
    scheduleUpdate();

    return () => {
      cancelAnimationFrame(frame);
      viewport.removeEventListener('scroll', scheduleUpdate);
      scrollArea?.removeEventListener('wheel', onScrollInteraction);
      scrollArea?.removeEventListener('touchstart', onScrollInteraction);
      scrollArea?.removeEventListener('pointerdown', onScrollInteraction);
      resizeObserver.disconnect();
      if (viewportRef.current === viewport) viewportRef.current = null;
      onScrollElementsChange(null, null);
    };
  }, [onScrollElementsChange, onScrollInteraction, updateRange]);

  useEffect(() => {
    const viewport = viewportRef.current;
    const root = rootRef.current;
    if (!viewport || !root) return;

    if (pages.length <= 0) return;
    const clampedCurrent = Math.min(Math.max(current, 0), pages.length - 1);
    const top = root.offsetTop + clampedCurrent * rowHeight;
    const bottom = top + rowHeight;
    const viewportTop = viewport.scrollTop + root.offsetTop;
    const viewportBottom = viewport.scrollTop + viewport.clientHeight;

    if (top < viewportTop) {
      viewport.scrollTo({ top: top - root.offsetTop, behavior: scrollBehavior() });
    } else if (bottom > viewportBottom) {
      viewport.scrollTo({ top: bottom - viewport.clientHeight, behavior: scrollBehavior() });
    } else {
      activeRef.current?.scrollIntoView({
        block: 'nearest',
        inline: 'nearest',
        behavior: scrollBehavior(),
      });
    }
  }, [activeRef, current, pages.length, rowHeight]);

  const visibleRange = clampVisibleRange(range, current, pages.length);
  const visible = [];
  for (let i = visibleRange.start; i < visibleRange.end; i++) {
    visible.push(
      <div
        key={i}
        className="absolute right-0 left-0"
        style={{ top: i * rowHeight, height: rowHeight }}
      >
        {renderThumb(pages[i], i)}
      </div>,
    );
  }

  return (
    <div ref={rootRef} className="relative" style={{ height: pages.length * rowHeight }}>
      {visible}
    </div>
  );
}

type VisibleRange = { start: number; end: number };

function clampVisibleRange(range: VisibleRange, current: number, count: number): VisibleRange {
  if (count <= 0) return { start: 0, end: 0 };
  if (range.start >= 0 && range.start < count && range.start < range.end) {
    return { start: range.start, end: Math.min(range.end, count) };
  }
  const clampedCurrent = Math.min(Math.max(current, 0), count - 1);
  return getInitialVisibleRange(clampedCurrent, count);
}

function getVisibleRange(
  scrollTop: number,
  count: number,
  viewportHeight: number,
  rowHeight: number,
): VisibleRange {
  if (count <= 0) return { start: 0, end: 0 };
  const visibleRows = Math.max(1, Math.ceil(viewportHeight / rowHeight));
  const firstVisible = Math.min(count - 1, Math.max(0, Math.floor(scrollTop / rowHeight)));
  const start = Math.max(0, firstVisible - VIRTUAL_OVERSCAN);
  const end = Math.min(count, firstVisible + visibleRows + VIRTUAL_OVERSCAN + 1);
  return { start, end };
}

function getInitialVisibleRange(current: number, count: number): VisibleRange {
  if (count <= 0) return { start: 0, end: 0 };
  const start = Math.max(0, current - VIRTUAL_OVERSCAN);
  const end = Math.min(count, current + VIRTUAL_OVERSCAN + 1);
  return { start, end };
}

function scrollBehavior(): ScrollBehavior {
  return prefersReducedMotion() ? 'auto' : 'smooth';
}

function ThumbContents({
  index,
  total,
  active,
  page: PageComp,
  design,
  scale,
  thumbWidth,
  height,
  moduleTransition,
}: {
  index: number;
  total: number;
  active: boolean;
  page: Page;
  design?: DesignSystem;
  scale: number;
  thumbWidth: number;
  height: number;
  moduleTransition?: SlideTransition;
}) {
  const t = useLocale();
  const boxRef = useRef<HTMLDivElement | null>(null);
  const [hasSteps, setHasSteps] = useState(false);

  // Steps live in JSX and can't be introspected statically — detect them from
  // the already-rendered thumbnail DOM, where each Step emits `data-osd-step`.
  // biome-ignore lint/correctness/useExhaustiveDependencies: re-detect when the page at this slot changes (reorder/edit reuses the index)
  useEffect(() => {
    setHasSteps(boxRef.current?.querySelector('[data-osd-step]') != null);
  }, [PageComp]);

  const hasTransition = Boolean(PageComp.transition ?? moduleTransition);
  const commentCount = usePageCommentCounts()?.get(index) ?? 0;

  return (
    <>
      <div className="mt-1.5 flex w-7 shrink-0 flex-col items-end gap-1">
        <span
          className={cn(
            'font-mono text-[10px] font-medium tracking-[0.06em] tabular-nums uppercase',
            active ? 'text-brand' : 'text-muted-foreground/70',
          )}
        >
          {pad2(index + 1)}
        </span>
        {commentCount > 0 && <CommentCountBadge count={commentCount} />}
        {(hasTransition || hasSteps) && (
          <div className="flex flex-col items-end gap-0.5">
            {hasTransition && (
              <ThumbIndicator icon={Sparkles} label={t.thumbnailRail.transitionIndicator} />
            )}
            {hasSteps && (
              <ThumbIndicator icon={ListOrdered} label={t.thumbnailRail.stepsIndicator} />
            )}
          </div>
        )}
      </div>
      <div
        ref={boxRef}
        className={cn(
          'relative shrink-0 overflow-hidden rounded-[4px] border bg-card motion-safe:transition-[border-color,box-shadow]',
          active
            ? 'border-brand shadow-[0_0_0_1px_var(--brand)]'
            : 'border-hairline group-hover/thumb:border-foreground/25',
        )}
        style={{ width: thumbWidth, height }}
      >
        <SlideCanvas scale={scale} center={false} flat freezeMotion design={design}>
          <SlidePageProvider index={index} total={total}>
            <PageComp />
          </SlidePageProvider>
        </SlideCanvas>
      </div>
    </>
  );
}

function ThumbIndicator({ icon: Icon, label }: { icon: LucideIcon; label: string }) {
  return (
    <Tooltip>
      <TooltipTrigger
        render={
          <span
            role="img"
            aria-label={label}
            className={cn(
              'flex size-3.5 items-center justify-center text-muted-foreground/55',
              'motion-safe:transition-colors group-hover/thumb:text-muted-foreground/80',
            )}
          >
            <Icon className="size-3" strokeWidth={2} />
          </span>
        }
      />
      <TooltipContent side="right" sideOffset={6}>
        {label}
      </TooltipContent>
    </Tooltip>
  );
}

function ThumbContextMenu({
  index,
  actions,
  pageCount,
  ariaLabel,
  children,
}: {
  index: number;
  actions: ThumbnailActions;
  pageCount: number;
  ariaLabel: string;
  children: React.ReactNode;
}) {
  const t = useLocale();
  const canDelete = pageCount > 1;
  return (
    <ContextMenu>
      <ContextMenuTrigger aria-label={ariaLabel} render={children as React.ReactElement} />
      <ContextMenuContent className="min-w-[180px]">
        <ContextMenuItem onClick={() => actions.onDuplicate(index)}>
          <Copy />
          {t.thumbnailRail.duplicatePage}
        </ContextMenuItem>
        <ContextMenuSeparator />
        <ContextMenuItem
          variant="destructive"
          disabled={!canDelete}
          onClick={() => {
            if (canDelete) actions.onDelete(index);
          }}
        >
          <Trash2 />
          {t.thumbnailRail.deletePage}
        </ContextMenuItem>
      </ContextMenuContent>
    </ContextMenu>
  );
}

function SortableRail({
  pages,
  onReorder,
  onSelect,
  children,
}: {
  pages: Page[];
  onReorder: (from: number, to: number) => void;
  onSelect: (index: number) => void;
  children: React.ReactNode;
}) {
  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 5 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates }),
  );

  const items = pages.map((_, i) => i + 1);

  const handleDragStart = (event: DragStartEvent) => {
    const i = (event.active.id as number) - 1;
    if (i >= 0) onSelect(i);
  };

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    if (!over || active.id === over.id) return;
    const from = (active.id as number) - 1;
    const to = (over.id as number) - 1;
    if (from < 0 || to < 0 || from === to) return;
    onReorder(from, to);
  };

  return (
    <DndContext
      sensors={sensors}
      collisionDetection={closestCenter}
      onDragStart={handleDragStart}
      onDragEnd={handleDragEnd}
    >
      <SortableContext items={items} strategy={verticalListSortingStrategy}>
        {children}
      </SortableContext>
    </DndContext>
  );
}

function SortableThumb({
  index,
  active,
  activeRef,
  onSelect,
  onArrowKeyDown,
  ariaLabel,
  children,
  ...rest
}: {
  index: number;
  active: boolean;
  activeRef: React.MutableRefObject<HTMLButtonElement | null> | undefined;
  onSelect: () => void;
  onArrowKeyDown: React.KeyboardEventHandler<HTMLButtonElement>;
  ariaLabel: string;
  children: React.ReactNode;
} & Omit<
  React.ButtonHTMLAttributes<HTMLButtonElement>,
  'onClick' | 'aria-label' | 'aria-current' | 'type' | 'style' | 'className' | 'ref' | 'children'
>) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({
    id: index + 1,
    transition: { duration: 180, easing: 'var(--ease-swift)' },
  });

  const setRef = (node: HTMLButtonElement | null) => {
    setNodeRef(node);
    if (activeRef) activeRef.current = node;
  };

  const yOnlyTransform = transform ? { ...transform, x: 0 } : transform;

  return (
    <button
      {...rest}
      ref={setRef}
      type="button"
      onClick={onSelect}
      onKeyDownCapture={isDragging ? undefined : onArrowKeyDown}
      aria-label={ariaLabel}
      aria-current={active ? 'page' : undefined}
      style={{
        transform: CSS.Transform.toString(yOnlyTransform),
        transition,
        touchAction: 'none',
      }}
      className={cn(
        thumbButtonClass(active),
        isDragging && 'z-10 cursor-grabbing opacity-60 shadow-edge ring-1 ring-brand',
      )}
      {...attributes}
      {...listeners}
    >
      {children}
    </button>
  );
}
