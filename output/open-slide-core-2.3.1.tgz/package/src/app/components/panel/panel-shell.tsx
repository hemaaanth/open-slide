import { useEffect, useState } from 'react';
import { ScrollArea } from '@/components/ui/scroll-area';

export const PANEL_W = 320;
export const PANEL_TRANSITION_MS = 240;

// Defer the width expansion to the next frame so the browser paints once
// at width=0 first; otherwise the transition has no starting frame.
export function useAnimatedOpen(open: boolean): boolean {
  const [animVisible, setAnimVisible] = useState(false);
  useEffect(() => {
    if (open) {
      const id = requestAnimationFrame(() => setAnimVisible(true));
      return () => cancelAnimationFrame(id);
    }
    setAnimVisible(false);
  }, [open]);
  return animVisible;
}

// Stay mounted through the close-out width transition so the panel
// visibly collapses instead of vanishing.
export function usePanelMount(open: boolean): { mounted: boolean; animVisible: boolean } {
  const [mounted, setMounted] = useState(false);
  useEffect(() => {
    if (open) {
      setMounted(true);
      return;
    }
    const t = setTimeout(() => setMounted(false), PANEL_TRANSITION_MS);
    return () => clearTimeout(t);
  }, [open]);
  const animVisible = useAnimatedOpen(open && mounted);
  return { mounted, animVisible };
}

type PanelShellProps = {
  uiAttr: 'inspector' | 'design';
  header: React.ReactNode;
  banner?: React.ReactNode;
  footer?: React.ReactNode;
  children: React.ReactNode;
};

export function PanelShell({ uiAttr, header, banner, footer, children }: PanelShellProps) {
  const dataAttrs = uiAttr === 'inspector' ? { 'data-inspector-ui': '' } : { 'data-design-ui': '' };
  return (
    <aside {...dataAttrs} className="flex h-full w-full min-w-0 bg-sidebar">
      <div className="flex h-full w-full min-w-0 flex-col">
        <header className="flex h-9 shrink-0 items-center justify-between gap-2 border-b border-hairline px-3">
          {header}
        </header>
        {banner}
        <ScrollArea className="min-h-0 flex-1">
          <div className="flex min-h-full flex-col">
            {children}
            {footer && <div className="mt-auto">{footer}</div>}
          </div>
        </ScrollArea>
      </div>
    </aside>
  );
}
